using System;

namespace RandPasscode.Models
{
    public class MyModel
    {
       
    }
}